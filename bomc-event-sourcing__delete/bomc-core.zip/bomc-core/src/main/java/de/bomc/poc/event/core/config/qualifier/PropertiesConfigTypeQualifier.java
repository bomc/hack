package de.bomc.poc.event.core.config.qualifier;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import de.bomc.poc.event.core.config.type.PropertiesConfigTypeEnum;

/**
 * A qualifier for configuration type properties.
 * 
 * @author <a href="mailto:michael_boerner@t-online.de">Michael Börner</a>
 * @version $Revision: $ $Author: $ $Date: $
 * @since 03.07.2018
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.TYPE, ElementType.METHOD})
public @interface PropertiesConfigTypeQualifier {

	PropertiesConfigTypeEnum type();
}
