package de.bomc.poc.event.core.category;

/**
 * A category marker interface for modul tests.
 * 
 * @author <a href="mailto:michael_boerner@t-online.de">Michael Börner</a>
 * @version $Revision: $ $Author: $ $Date: $
 * @since 03.07.2018
 */
public interface ModulTest {
	//
}
